#include <stdio.h>
#include <process.h>
#include <windows.h>


int main(void)
{
	HANDLE hprinter;

	if (!OpenPrinter("CP 324 HRS", &hprinter, 0))
	{
		printf("error opening printer!\n");
		exit(1);
	}
	printf("printer opened successfully!\n");
	printf("1111111111111111111\n");
	printf("2222222222222222\n");
	printf("33333333333\n");
	return 0;

}
